package main

import "fmt"

// 1. Buat sebuah struct bernama Person dengan satu member name bertipe string.
type Person struct {
	name string
}

// 2. Membuat method printName untuk struct Person.
func (p Person) printName() {
	fmt.Println(p.name)
}

func main() {
	// 3. Membuat variabel bertipe Person.
	var person Person

	// 4. Memberikan nilai "John Doe" pada member name.
	person.name = "John Doe"

	// 5. Memanggil method printName dari variabel person.
	person.printName()
}
